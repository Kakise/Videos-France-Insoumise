/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'fi', {
	bold: 'Lihavoitu',
	italic: 'Kursivoitu',
	strike: 'Yliviivattu',
	subscript: 'Alaindeksi',
	superscript: 'Yläindeksi',
	underline: 'Alleviivattu'
} );
