/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'fr', {
	ltr: 'Direction du texte de la gauche vers la droite',
	rtl: 'Direction du texte de la droite vers la gauche'
} );
