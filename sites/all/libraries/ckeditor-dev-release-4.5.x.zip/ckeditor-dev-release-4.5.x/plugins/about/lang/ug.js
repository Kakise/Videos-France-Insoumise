/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ug', {
	copy: 'Copyright &copy; $1. نەشر ھوقۇقىغا ئىگە',
	dlgTitle: 'CKEditor ھەققىدە',
	help: '$1 نى زىيارەت قىلىپ ياردەمگە ئېرىشىڭ',
	moreInfo: 'تور تۇرايىمىزنى زىيارەت قىلىپ كېلىشىمگە ئائىت تېخىمۇ كۆپ ئۇچۇرغا ئېرىشىڭ',
	title: 'CKEditor ھەققىدە',
	userGuide: 'CKEditor ئىشلەتكۈچى قوللانمىسى'
} );
