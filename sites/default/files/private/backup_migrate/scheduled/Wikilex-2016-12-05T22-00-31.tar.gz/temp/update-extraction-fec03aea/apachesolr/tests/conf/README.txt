
The conf files in this directory are complete in addition to schema.xml and solrconfig.xml
in order to provide what a core needs to run.  However, these are only for testing.  For
production start from the ones from the example/solr directory of a Solr 1.4.x
release tarball.


